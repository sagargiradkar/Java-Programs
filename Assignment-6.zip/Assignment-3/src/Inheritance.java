import java.util.Scanner;
class employee{
	public
	String employeeName,address,mailId;
	String empID,mobNo;
	float BP,DA,HRA,PF,CF,GS,NS;
		//Creation of 
	employee() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the name of employee :");
		employeeName=sc.nextLine();
		System.out.println("===================================================");
		System.out.print("Enter employee ID :");
		empID=sc.nextLine();
		System.out.println("===================================================");
		System.out.print("Enter Employee Email-ID :");
		mailId=sc.nextLine();
		System.out.println("===================================================");
		System.out.print("Enter Mobile number of employee :");
		mobNo=sc.nextLine();
		System.out.println("===================================================");
		System.out.print("Enter address of employee :");
		address=sc.nextLine();
		System.out.println("===================================================");
	}
		
		public void  calculate() {
		
			Scanner sc=new Scanner(System.in);
			System.out.print("Enter the Basic Salary Of employee :");
			BP=sc.nextFloat();
			DA=(97*BP)/100;
			HRA=(10*BP)/100;
			PF=(12*BP)/100;
			CF=(0.1f*BP)/100;
			GS=BP+DA+HRA;
			NS=GS-PF-CF;	
		}	
		public void Display() {
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%35s","MICROSOFT CORPORATION")+String.format("%15s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%37s","SALARY SLEEP OF EMPLYEE")+String.format("%13s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%40s","PAY SLIP FOR OCTOMBER 2022")+String.format("%10s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%s","NAME OF EMPLOYEE ")+String.format("%2s",":")+String.format("%s",employeeName)+String.format("%9s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%s","EMPLOYEE ID ")+String.format("%7s",":")+String.format("%s",empID)+String.format("%22s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%s","EMPLOYEE EMAIL ")+String.format("%4s",":")+String.format("%s",mailId)+String.format("%7s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%s","EMPLOYEE MOBILE NO.")+String.format("%s",":")+String.format("%s",mobNo)+String.format("%17s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%s","EMPLOYEE ADDRESS")+String.format("%4s",":")+String.format("%s",address)+String.format("%12s","|"));
			System.out.println("===================================================");
			System.out.println(String.format("%s","|")+String.format("%50s","|"));
			System.out.println("===================================================");
			
			System.out.println("|      EARNINGS "+String.format("%12s","|")+"     DEDUCTIONS"+String.format("%8s","|"));
			System.out.println("===================================================");
			System.out.println("|BASIC SALARY "+String.format("%5s",":")+BP+String.format("%2s","|")+"PF     :"+PF+String.format("%9s","|"));
			System.out.println("===================================================");
			System.out.println("|DEARNESS ALLOWNCE"+String.format("%s",":")+DA+String.format("%2s","|")+"CF     :"+CF+String.format("%11s","|"));
			System.out.println("===================================================");
			System.out.println("|HRA"+String.format("%15s",":")+HRA+String.format("%3s"," |")+"    "+""+String.format("%19s","|"));
			System.out.println("===================================================");
			
			System.out.println("|TOTAL EARNINNG "+String.format("%3s",":")+GS+String.format("%s","|")+"TOTAL DEDUCTION:"+(PF-CF)+String.format("%s","|"));
			System.out.println("===================================================");
			System.out.println("|    NET SALARY"+String.format("%10s",":")+NS+String.format("%5s"," ")+String.format("%14s","|"));
			System.out.println("===================================================");

		}	
}
class Programmer extends employee{
	Programmer(){
		super();
		this.calculate();
		this.Display();
	}
	
}
class Team_Lead extends employee{
	Team_Lead(){
		super();
		this.calculate();
		this.Display();
	}
}
class Assistance_Project_Manager extends employee{
	Assistance_Project_Manager(){
		super();
		this.calculate();
		this.Display();
	}
}
class Project_Manager extends employee{
	Project_Manager(){
		super();
		this.calculate();
		this.Display();
	}
}
public class Inheritance {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		 int choice;
		do {
			System.out.println("===================================================");	
		 System.out.println("||          Designations                         ||");
		 System.out.println("===================================================");
		 System.out.println("||          1.Programmer                         ||");
		 System.out.println("===================================================");
		 System.out.println("||          2.Team_Lead                          ||");
		 System.out.println("===================================================");
		 System.out.println("||          3.Assistance_Project_Manager         ||");
		 System.out.println("===================================================");
		 System.out.println("||          4.Project_Manager                    ||");
		 System.out.println("===================================================");
		 System.out.println("||          5.Exit                               ||");
		 System.out.println("===================================================");
		 System.out.print("||Enter the Designation of the employee : ");
		 choice=sc.nextInt();
		 System.out.println("===================================================");
		 
		 switch(choice) {
		 case 1: Programmer obj1=new Programmer();
		 	
		 		break;
		 case 2: Team_Lead obj2=new Team_Lead();
		       
		        break;
		 case 3 :Assistance_Project_Manager obj3=new Assistance_Project_Manager();
	 		
	 		break;
		 case 4:Project_Manager obj4=new Project_Manager();
	
	 		break;
		 case 5:System.out.print("Exit-Thank You");
		 	break;
	 	 default:
	 		 System.out.print("ENTER VALID INPUT!!");
		 }
		}while(choice!=5);
		 
	}
}
