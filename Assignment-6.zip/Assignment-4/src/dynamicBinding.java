import java.util.Scanner;

abstract class shape{
	
	double length,breadth;
	
	Scanner sc=new Scanner(System.in);
	
	public shape(){

	}
	public void getdata()
		{
		System.out.print("Enter the length :");
		
		length=sc.nextDouble();
		
		System.out.print("Enter the breadth :");
		
		breadth=sc.nextDouble();
	}
	public abstract void compute_area() ;
}
class triangle extends shape{
	
	public void compute_area()
	{
		double area=(length*breadth)/2;
		
		System.out.println("Area of Triangle is "+area);
}
	
}

class rectangle extends shape{
	public void compute_area() {
		
	double area=length*breadth;
	
	System.out.println("Area of Rectangle is "+area);
}
}

public class dynamicBinding {

	public static void main(String[] args) {
		
		triangle obj1=new triangle();
		
		System.out.println("Enter the Data for Triangle");
		
		obj1.getdata();
		
		obj1.compute_area();
		
		rectangle obj2=new rectangle();
		
		System.out.println("Enter the Data for Rectangle");
		
		obj2.getdata();
		
		obj2.compute_area();
		
		
	}

}
