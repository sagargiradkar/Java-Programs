import java.util.*;
public class ShoppingCartTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ShoppingCart cart = new ShoppingCart();
		System.out.println("=============================================");
		System.out.println("||  ASSIGNMENT OF STRATEGY DESIGN PATTERN  ||");
		System.out.println("=============================================\n");
		System.out.println("=============================================");
		System.out.println("||          WELCOME TO AMAZON SHOP         ||");
		System.out.println("=============================================\n");
		Scanner sc=new Scanner(System.in);
		int choice;
		do {
		System.out.println("=============================================");
		System.out.println("||          MAIN MENU FOR SHOPPING        ||");
		System.out.println("=============================================");
		System.out.println("1] ORDER ITEMS");
		System.out.println("2] PAYMENT THROUGH CREDID/DEBIT CARD");
		System.out.println("3] PAYMENT THROUGH PAYPAL ");
		System.out.println("4] PAYMENT THROUGH BIT-COIN");
		System.out.println("5] EXIT FROM PROGRAM\n");
		System.out.print("Enter a choice :");
		choice=sc.nextInt();
		System.out.println("=============================================\n");
		switch(choice) {
		case 1:
			int n;
			int price;
			String itemsName;
			System.out.println("Enter How much items you want to buy:");
			n=sc.nextInt();
			for(int i=1;i<=n;i++) {
				System.out.print("Enter item name:");
				itemsName=sc.next();
				System.out.print("Enter a price :");
				price=sc.nextInt();				
			
				Item item1 = new Item(itemsName,price);
				cart.addItem(item1);
			}
			break;
		case 2:
			//pay by credit card
			System.out.println("=============================================");
			System.out.println("||   ENTER CREDIT/DEBIT CARD DETAILS   || ");
			System.out.println("=============================================\n");
			String name,CardNo = null,CVV = null,DOE = null;
			System.out.print("Enter Card Holder Name :");
			name=sc.next();
			System.out.print("Enter Card Number :");
			name=sc.next();
			System.out.print("Enter CVV PIN :");
			name=sc.next();
			System.out.print("Enter Date Of  Expiry :");
			name=sc.next();
			System.out.println("=============================================");
			cart.pay(new CreditCardStrategy(name,CardNo,CVV,DOE));
			System.out.println("=============================================\n");
			break;
		case 3:
			System.out.println("=============================================");
			System.out.println("||        ENTER PAY PAL DETAIS             || ");
			System.out.println("=============================================\n");
			//pay by paypal
			String mail,pwd;
			System.out.print("Enter Your Email :");
			mail=sc.next();
			System.out.print("Enter Your Password :");
			pwd=sc.next();
			System.out.println("=============================================");
			cart.pay(new PaypalStrategy(mail,pwd));
			System.out.println("=============================================");
			break;
		case 4://pay by bitcoin
			System.out.println("=============================================");
			System.out.println("||        ENTER BIT-COIN DETAIS            || ");
			System.out.println("=============================================\n");
			String vid,pwds;
			System.out.print("Enter Your Bit Coin Wallet ID :");
			vid=sc.next();
			System.out.print("Enter Your Password :");
			pwds=sc.next();
			System.out.println("=============================================");
			cart.pay(new bitCoinStrategy(vid,pwds));
			System.out.println("=============================================");
			break;
		case 5:
			System.out.println("Succesfully Exit From program");
			System.out.println("Thank-You");
			break;
		default:System.out.println("Enter valid input ?????");
			
		}
		}while(choice!=5);
	}

}
