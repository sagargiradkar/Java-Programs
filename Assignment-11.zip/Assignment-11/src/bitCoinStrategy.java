
public class bitCoinStrategy implements PaymentStrategy {
	private String bitmail;
	private String password;
	public bitCoinStrategy(String mail, String pwd) {
		// TODO Auto-generated constructor stub
		this.bitmail=bitmail;
		this.password=pwd;
	}
	//@Override
	public void pay(int amount) {
		System.out.println(amount + " paid using BitCoin.");
	}
}

	