
public interface Car {
	  
	 
		public String getModel();
		

		public void setWheel(String wheel);
		

		public String getWheel();
		
		
		public void setEngine(String engine);
		

		public String getEngine();
		
	   
	}

