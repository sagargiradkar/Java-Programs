import java.util.*;
public class TestFactoryPattern {
	
	CarFactory carBuilder;
	Car car;
    public static void main(String[] args) {
    	TestFactoryPattern client = new TestFactoryPattern();
       client.buildCarMethod();
    }
    public void buildCarMethod() {
    	Scanner sc=new Scanner(System.in);
    	int choice = 0;
    	System.out.println("===================================");
        System.out.println("||  ASSIGNMENT OF FACTORY DESIGN ||");
        System.out.println("===================================\n");
    	String model,engine,wheel;
    	do {
        
        System.out.println("===================================");
        System.out.println("||  MAIN MENU FOR DESIGNING CAR  ||");
        System.out.println("===================================\n");
        System.out.println("1] DESIGN HATCHBACK CAR");
        System.out.println("2] DESIGN SEDAN CAR");
        System.out.println("3] DESIGN SUV CAR");
        System.out.println("4] EXIT FROM PROGRAM\n");
        System.out.println("Enter a choice which ");
        System.out.print("you want to design a car :");
        choice=sc.nextInt();
		switch(choice) {
        case 1:
        	System.out.println("Building Hatchback car\n");
    		carBuilder = new HatchbackCarFactory();
    		System.out.print("Enter which model you want :");
    		model=sc.next();
    		System.out.print("Enter which Engine you want :");
    		engine=sc.next();
    		System.out.print("Enter which Wheels you want :");
    		wheel=sc.next();
    		//car = carBuilder.buildCar("Polo", "Michelin", "VW");
    		car = carBuilder.buildCar(model,engine,wheel);
    		System.out.println("\n");
    		System.out.println("Your car is now going to ");
    		System.out.println("ready please wait for few days");
    		System.out.println("Your car is ready with following specifiaction ");
    		System.out.println("which you given to the factory");
            System.out.println("Car is assembled Model of car is: "+ car.getModel());
            System.out.println("Car is assembled Engine of car is: "+ car.getEngine());
            System.out.println("Car is assembled Wheel of car is: "+ car.getWheel());
            break;
        case 2:
        	System.out.println("Building SEDAN car");
        	carBuilder = new SedanCarFactory();
    		System.out.print("Enter which model you want :");
    		model=sc.next();
    		System.out.print("Enter which Engine you want :");
    		engine=sc.next();
    		System.out.print("Enter which Wheels you want :");
    		wheel=sc.next();
    		//car = carBuilder.buildCar("Dzire", "MRF", "Suzuki");
    		car = carBuilder.buildCar(model,engine,wheel);
    		System.out.println("\n");
    		System.out.println("Your car is now going to ");
    		System.out.println("ready please wait for few days");
    		System.out.println("Your car is ready with following specifiaction ");
    		System.out.println("which you given to the factory");
            System.out.println("Car is assembled Model of car is: "+ car.getModel());
            System.out.println("Car is assembled Engine of car is: "+ car.getEngine());
            System.out.println("Car is assembled Wheel of car is: "+ car.getWheel());
        	break;
        case 3:
        	System.out.println("Building SUV car");
        	carBuilder = new SUVCarFactory();
    		System.out.print("Enter which model you want :");
    		model=sc.next();
    		System.out.print("Enter which Engine you want :");
    		engine=sc.next();
    		System.out.print("Enter which Wheels you want :");
    		wheel=sc.next();
    		//car = carBuilder.buildCar("Innova", "Bridgestone", "Fiat");
    		car = carBuilder.buildCar(model,engine,wheel);
    		System.out.println("\n");
    		System.out.println("Your car is now going to ");
    		System.out.println("ready please wait for few days");
    		System.out.println("Your car is ready with following specifiaction ");
    		System.out.println("which you given to the factory");
            System.out.println("Car is assembled Model of car is: "+ car.getModel());
            System.out.println("Car is assembled Engine of car is: "+ car.getEngine());
            System.out.println("Car is assembled Wheel of car is: "+ car.getWheel());
            break;
        case 4:System.out.println("Succesfully Exit From program");
        		System.out.println("Thank-You");
        		break;
        default:System.out.println("Enter valid input");
        }      
    	}while(choice!=4);
    }
}
