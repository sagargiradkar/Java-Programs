import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

class template<T>{
	
	ArrayList<T>list=new ArrayList<T>();
	
	//============================ Array To Take Data Of T type =============================//
	void assign(T arr[],int n)  //assign method is declare here..
	{
		for(int i=0;i<n;i++)
		{
			list.add(arr[i]);
		}
	}
	
	//============================Display Array  =============================//
	void display_list()      //display method is declare here..
	{
		 Iterator<T>itr=list.iterator();
		 System.out.println("'\nThe elements are :");
		 while(itr.hasNext())
		 {
			 System.out.print(itr.next()+" ");
		 }
		 System.out.println();
		 System.out.println("\n");
		 System.out.println("==============================================");
	}
	
	//============================Method of Palindrome=============================//
	void check_palindrome() 
	{
		String R,S;
		
		T temp;
		
		boolean flag=false;
		
		Iterator<T>itr=list.iterator();
		
		//System.out.println("\nPalindrome Integers Are : ");
		int m=0;
		while(itr.hasNext())
		{
			temp=itr.next();
			
			S=temp.toString();
			StringBuilder SR = new StringBuilder(S);
			
			R=SR.reverse().toString();
			
			if(S.equals(R))
			{
				m++;
				flag=true;
				System.out.println("Palindrme :"+temp);
			}
		} 
		
		if(flag==false)
		{
			System.out.println("\n>>Palindrome Not Found !!!"); 
		}
		
		System.out.println(">>The total number of pallindromes element are "+m);
	}
	//============================Method of Even Odd=============================//
	void count_even_odd()
	{
		int even=0;
		int odd=0;
		
		Iterator<T>itr=list.iterator();
		
			T temp;
			String S;
			int i;
			//double A;
			
			while(itr.hasNext())
			{
				temp=itr.next();
				
				S=temp.toString();
				
				i=Integer.parseInt(S);
				
				if(i%2==0)
				{
					even++ ;
					System.out.println("Even :"+temp);
				}
				
				else
				{
					odd++ ;
					System.out.println("Odd :"+temp);
				}
			}
		  System.out.println("==============================================");
		  System.out.println("\n>>The Total Number of Even Integers are :"+even);
		  
		  System.out.println("\n>>The Total Number of Odd Integers are :"+odd);
	}
	//========================================= PRIME METHOD =========================================//		
	void Prime_no(){
		
		//boolean flag=false;
		Iterator<T>itr=list.iterator();
		T temp;
		String S;
		int i;
		int m=0;
		while(itr.hasNext())
		{
			temp=itr.next();
			
			S=temp.toString();
			
			i=Integer.parseInt(S);
			int bool=0;
			for(int x=2;x<i;x++) {
				if(i%x==0) {
					bool=1;
					break;
				}
				
			}
			if(bool==0) {
				m++;
				System.out.println("Prime :"+temp);
			}
		}
		System.out.println(">>The total number of prime numbers are "+m);
		
		
	}
}


//*******************Main Class****************

public class Main {

	public static void main(String[] args) {
		
		int i,n=0;
		int Choice;
		int ch;
		int chh;
		int choice;
		System.out.println("==============================================");
		System.out.println("||         ASSIGNMENT OF TEMPLATE           ||");
		System.out.println("==============================================");
		Scanner sc =new Scanner(System.in);
 do{	
	 System.out.println(" \n ");
	 	System.out.println("==============================================");
		System.out.println("||               MAIN MENU                  ||");
		System.out.println("==============================================");	
		
		 System.out.println("1] Check For Integer ");
		 System.out.println("2] Check For Float");
		 System.out.println("3] Check For String");
		 System.out.println("4] Exit\n");
		 System.out.print("Enter your choice -:");
		 Choice=sc.nextInt();
		
		 
		 
		 
	
  switch (Choice) {
  
  case 1:
	  
	  System.out.println("How Many Integer elements you want :");
		n=sc.nextInt();
		Integer a[]=new Integer[n];
		System.out.println("Enter elements : "+" ");
		
		for(i=0;i<n;i++)
		{	System.out.print("Enter the element at "+i+" index number :");
			a[i]=sc.nextInt();
		}
		
	do{
		 
		System.out.println("==============================================");
		System.out.println("||       SELECT OPTINS FROM BELOW           ||");
		System.out.println("==============================================");
			System.out.println("1] Even Integer AND Odd Integer");
			System.out.println("2] Palindrome");
			System.out.println("3] prime");
			System.out.println("4] Exit\n");
			
			System.out.print("Enter your choice :-");
			ch=sc.nextInt();
		
		template<Integer>obj= new template<Integer>();
		
		
		obj.assign(a,n);
		obj.display_list();
		switch(ch) 
		{
		case 1:
	    obj.count_even_odd();
		
	    break;
	    
		case 2:
			
		obj.check_palindrome();
	
		break;
		
		case 3:
		obj.Prime_no();
		break;
		
		default:
			System.out.println("EXit !!!!");
			break;
		}
	}while(ch!=4 );
		
		break;
	
	
  case 2:
	  
	  System.out.println("How many float elements you want :");
		
		n=sc.nextInt();
		
		Float b[]=new Float[n];
		
		System.out.println("Enter Elements :"+" ");	
		for(i=0;i<n;i++)
		{
			System.out.print("Enter the element at "+i+" index number :");
			b[i]=sc.nextFloat();
		}
		do{
			

		System.out.println("==============================================");
		System.out.println("||       SELECT OPTINS FROM BELOW           ||");
		System.out.println("==============================================");
		System.out.println("1] Palindrome");
		System.out.println("2] Exit\n");
		
		System.out.print("Enter your choice -:");
		chh=sc.nextInt();
		
		template<Float>obj1=new template<Float>();
		
		obj1.assign(b,n);
		obj1.display_list();
		
		switch(chh) 
		{
		
		case 1 :
			
			 obj1.check_palindrome();
		 break;
		
		default:
		  System.out.println("Exit !!!");
			break;
		
		}
	}while(chh!=2);
		
		break;
		
 
  case 3:
		
	  System.out.print("How many String elements you want :");
		
		n=sc.nextInt();
		
		String c[]=new String[n];
		System.out.println("Enter Elements :"+" ");
		
		for(i=0;i<n;i++)
		{
			System.out.print("Enter the element at "+i+" index number :");
			c[i]=sc.next();
		}
		
		do{
			
		System.out.println("==============================================");
		System.out.println("||       SELECT OPTINS FROM BELOW           ||");
		System.out.println("==============================================");
		System.out.println("1] Palindrome");
		System.out.println("2] Exit\n");
		
		System.out.print("\nEnter your choice :-");
		choice=sc.nextInt();
		
		template<String>obj2=new template<String>();
		
		obj2.assign(c, n);
		obj2.display_list();
		
		 switch(choice) {
		 
		 case 1:
		obj2.check_palindrome();
		break;
		
		default:
			System.out.println("Exit !!!!");
			break;
		
		 }
		 
	  }while(choice!=2);
		
	default:
		System.out.println("Program exit sucessfully !!!!");
  
     }
}while(Choice!=4);
 
 
	}

}
